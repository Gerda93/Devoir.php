<?php

function InsertionPersonel($code,$nom,$prenom,$Sexe,$Date_Naissance,$Nationalité,$Téléphone,$Email,$Type){
    
    return $_SESSION['Personnel'];
}